from flask import Flask, render_template, request, redirect, render_template_string
from flask_sqlalchemy import SQLAlchemy
import datetime
import os
from flask_admin import Admin
from flask_admin.contrib.sqla import ModelView
from flask_babelex import Babel
basedir = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)

app.config['SECRET_KEY'] = '3a7d6c9d2712428d0f0a'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///'+ os.path.join(basedir, 'test.db')
app.config['DEBUG'] = True
app.config['FLASK_ADMIN_SWATCH'] = 'cerulean'

babel = Babel(app)

@babel.localeselector
def get_locale():
    return 'rus'

admin = Admin(app, name='microblog', template_mode='bootstrap3')

db = SQLAlchemy(app)

class Row(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), unique=True, nullable=False)
    versions = db.Column(db.String(120), unique=True, nullable=False)
    description = db.Column(db.Text)
    start = db.Column(db.DateTime(timezone='MSK'))
    end = db.Column(db.DateTime)

    @property
    def time(self):
        return self.start.strftime('%d/%m/%Y') +' - '+self.end.strftime('%d/%m/%Y')

    def __repr__(self):
        return '<Row %r>' % self.name


class Mod(ModelView):
    form_args = dict(
        start=dict(format='%Y-%m-%d')  # changes how the input is parsed by strptime (12 hour time)
    )
    form_widget_args = dict(
        start={
            'data-date-format': u'YYYY-MM-DD',
            'data-show-meridian': 'False'
        }  # changes how the DateTimeField displays the time
    )

admin.add_view(Mod(Row, db.session))

@app.route('/')
def home():
    r = Row.query.all()
    return render_template('home.html', row=r)

@app.route('/e', methods = ['GET', 'POST'])
def edit():
    if request.method == 'POST':
        form = request.form
        daterange = form['time'].split(' - ')
        print(form['time'].split(' - '))
        if form['id']:
            print('update')
            task = Row.query.filter_by(id=form['id']).one()
            task.name = form['name']
            task.versions = form['versions']
            task.description = form['description']
            task.start = datetime.datetime.strptime(daterange[0], '%d/%m/%Y')
            task.end = datetime.datetime.strptime(daterange[1], '%d/%m/%Y')
            db.session.add(task)
            db.session.commit()
        else:
            print('create')
            task = Row()
            task.name = form['name']
            task.versions = form['versions']
            task.description = form['description']
            task.start = datetime.datetime.strptime(daterange[0], '%d/%m/%Y')
            task.end = datetime.datetime.strptime(daterange[1], '%d/%m/%Y')
            db.session.add(task)
            db.session.commit()
        return redirect('/e')
    r = Row.query.all()
    return render_template('edit.html', r=r)

@app.route('/dell/<id>', methods = ['GET', 'POST'])
def save(id):
    print('dell ', id)
    task = Row.query.filter_by(id=id).one()
    if request.method == 'POST':
        db.session.delete(task)
        db.session.commit()
        return redirect('/e')
    else:
        return render_template_string(
            """
            <form method="post">
            {{r}}
            <button type="submit" class="btn btn-primary">Да!</button>
            </form>
            """,
            r= task
        )


if __name__ == '__main__':
    app.run()